//: Playground - noun: a place where people can play

import UIKit

import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

print("Test")

class AsyncController{

    static func execute(after nbSeconds: Double, handler: @escaping (Bool) -> Void){
        DispatchQueue.main.asyncAfter(deadline: .now() + nbSeconds) {
            print("ok")
            handler(true)
        }
    }
    
    static func fetchPeopleFromDB(handler: @escaping ([String]) -> Void){
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            var people = ["test", "hello", "ok"]
            handler(people)
        }
        
    }
}

AsyncController.execute(after: 4) { (test) in
    print("Finished \(test)")
    AsyncController.fetchPeopleFromDB{ (people) in
        print(people)
        PlaygroundPage.current.finishExecution()
    }
    
}

print("Done")
